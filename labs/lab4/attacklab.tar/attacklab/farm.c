/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_464()
{
    return 3247476824U;
}

void setval_102(unsigned *p)
{
    *p = 2462550344U;
}

unsigned getval_336()
{
    return 2428995912U;
}

unsigned getval_434()
{
    return 3347663154U;
}

void setval_369(unsigned *p)
{
    *p = 3347662920U;
}

unsigned addval_248(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_303()
{
    return 2417531588U;
}

void setval_214(unsigned *p)
{
    *p = 1481779392U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_287()
{
    return 3281044105U;
}

unsigned getval_416()
{
    return 3372797593U;
}

unsigned getval_148()
{
    return 3221803405U;
}

void setval_393(unsigned *p)
{
    *p = 3263252127U;
}

unsigned addval_247(unsigned x)
{
    return x + 3526938249U;
}

unsigned addval_314(unsigned x)
{
    return x + 3531918857U;
}

unsigned getval_193()
{
    return 3286272840U;
}

unsigned addval_381(unsigned x)
{
    return x + 3286272264U;
}

void setval_271(unsigned *p)
{
    *p = 3286270280U;
}

unsigned getval_239()
{
    return 2430601544U;
}

void setval_176(unsigned *p)
{
    *p = 2429454677U;
}

unsigned addval_439(unsigned x)
{
    return x + 3286272328U;
}

void setval_317(unsigned *p)
{
    *p = 3677930125U;
}

unsigned getval_481()
{
    return 3232026249U;
}

unsigned addval_244(unsigned x)
{
    return x + 3225993865U;
}

unsigned getval_473()
{
    return 2430634313U;
}

void setval_343(unsigned *p)
{
    *p = 3532968329U;
}

void setval_351(unsigned *p)
{
    *p = 3675836041U;
}

unsigned getval_319()
{
    return 3525366155U;
}

unsigned getval_206()
{
    return 3674784395U;
}

void setval_406(unsigned *p)
{
    *p = 3682910857U;
}

unsigned getval_118()
{
    return 2446428579U;
}

unsigned getval_190()
{
    return 3380924809U;
}

unsigned addval_216(unsigned x)
{
    return x + 3229929113U;
}

unsigned getval_224()
{
    return 3534013065U;
}

unsigned getval_345()
{
    return 3676885385U;
}

void setval_321(unsigned *p)
{
    *p = 3532964489U;
}

void setval_444(unsigned *p)
{
    *p = 3767093354U;
}

void setval_107(unsigned *p)
{
    *p = 3677933209U;
}

unsigned getval_205()
{
    return 3286272344U;
}

unsigned getval_154()
{
    return 3223900553U;
}

unsigned addval_486(unsigned x)
{
    return x + 3677933961U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
